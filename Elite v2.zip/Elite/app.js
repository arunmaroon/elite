// ============================================
// COMBO DATA
// ============================================

const combosData = [
  {
    id: 'PR01',
    title: 'Cast Iron Combo PR01',
    description: 'Kadai 9" + Dosa Tawa Long Handle + Skillet 6"',
    price: '2,499',
    features: [
      'Kadai 9"',
      'Dosa Tawa Long Handle',
      'Skillet 6"'
    ],
    image: 'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
    images: [
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR01 - Kadai 9" + Dosa Tawa Long Handle + Skillet 6". Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR02',
    title: 'Cast Iron Combo PR02',
    description: 'Dosa Tawa 12" + Panniyarakkal 12 Pits + Mulbagal Tawa 9"',
    price: '2,299',
    features: [
      'Dosa Tawa 12"',
      'Panniyarakkal 12 Pits',
      'Mulbagal Tawa 9"'
    ],
    image: 'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
    images: [
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR02 - Dosa Tawa 12" + Panniyarakkal 12 Pits + Mulbagal Tawa 9". Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR03',
    title: 'Cast Iron Combo PR03',
    description: 'Neer Dosa Tawa 12" + Appachetty + Kadai 7"',
    price: '1,899',
    features: [
      'Neer Dosa Tawa 12"',
      'Appachetty',
      'Kadai 7"'
    ],
    image: 'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
    images: [
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR03 - Neer Dosa Tawa 12" + Appachetty + Kadai 7". Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR04',
    title: 'Cast Iron Combo PR04',
    description: 'Mulbagal Tawa 9" + Omlette Tawa + Tadka Pan',
    price: '3,299',
    features: [
      'Mulbagal Tawa 9"',
      'Omlette Tawa',
      'Tadka Pan'
    ],
    image: 'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
    images: [
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR04 - Mulbagal Tawa 9" + Omlette Tawa + Tadka Pan. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR05',
    title: 'Triply Combo PR05',
    description: 'Triply Kadai 22cm + Triply Frypan 22cm + Triply Sauce Pan 16cm',
    price: '3,599',
    features: [
      'Triply Kadai 22cm',
      'Triply Frypan 22cm',
      'Triply Sauce Pan 16cm'
    ],
    image: 'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg',
    images: [
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR05 - Triply Kadai 22cm + Triply Frypan 22cm + Triply Sauce Pan 16cm. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR06',
    title: 'Triply Combo PR06',
    description: 'Honey Comb Kadai 20cm + Fry Pan 20cm + Chapathi tawa 25 cm',
    price: '4,199',
    features: [
      'Honey Comb Kadai 20cm',
      'Fry Pan 20cm',
      'Chapathi tawa 25 cm'
    ],
    image: 'https://i.pinimg.com/1200x/4b/27/0e/4b270ebf10fd8909ec9d0692a20d2bd1.jpg',
    images: [
      'https://i.pinimg.com/1200x/4b/27/0e/4b270ebf10fd8909ec9d0692a20d2bd1.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR06 - Honey Comb Kadai 20cm + Fry Pan 20cm + Chapathi tawa 25 cm. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR07',
    title: 'Winter Combi PR07',
    description: 'Casserole Hotbox 1000ml + 2000ml + 3000ml',
    price: '2,799',
    features: [
      'Casserole Hotbox 1000ml',
      'Casserole Hotbox 2000ml',
      'Casserole Hotbox 3000ml'
    ],
    image: 'https://i.pinimg.com/736x/a2/c5/1d/a2c51d9344816eab8fd698defd07a55e.jpg',
    images: [
      'https://i.pinimg.com/736x/a2/c5/1d/a2c51d9344816eab8fd698defd07a55e.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR07 - Casserole Hotbox 1000ml + 2000ml + 3000ml. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR08',
    title: 'Pressure Cooker PR08',
    description: 'Triply 10 litre cooker',
    price: '3,899',
    features: [
      'Triply Construction',
      '10 Litre Capacity',
      'Premium Quality'
    ],
    image: 'https://i.pinimg.com/1200x/90/94/7e/90947e79a9d0db1e7dfba3f5ae42d0fb.jpg',
    images: [
      'https://i.pinimg.com/1200x/90/94/7e/90947e79a9d0db1e7dfba3f5ae42d0fb.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR08 - Triply 10 litre cooker. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR09',
    title: 'Travel Combi PR09',
    description: 'Elito Multi kettle 1.5 ltr + 5000ml hot box',
    price: '2,199',
    features: [
      'Elito Multi kettle 1.5 ltr',
      '5000ml hot box',
      'Travel-Friendly'
    ],
    image: 'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
    images: [
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR09 - Elito Multi kettle 1.5 ltr + 5000ml hot box. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR10',
    title: 'Aptiva Stove PR10',
    description: 'Aptiva SS stove 2 burner Jumbo + large burner',
    price: '4,499',
    features: [
      'Stainless Steel Build',
      '2 Burner Jumbo',
      'Large Burner'
    ],
    image: 'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
    images: [
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR10 - Aptiva SS stove 2 burner Jumbo + large burner. Could you provide more details and pricing? 📦'
  },
  {
    id: 'PR11',
    title: 'Glass Top Stove PR11',
    description: 'Innovative Glass Top Sleek Stove 2 Burner Jumbo + Large',
    price: '5,299',
    features: [
      'Glass Top Design',
      '2 Burner Jumbo',
      'Large Burner'
    ],
    image: 'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
    images: [
      'https://i.pinimg.com/736x/dc/3a/1e/dc3a1ef114c3b8d3539d8adb7cdc211b.jpg',
      'https://i.pinimg.com/1200x/fa/9b/d3/fa9bd31625c785376f341cb3d2e75c0a.jpg',
      'https://i.pinimg.com/736x/4e/b1/fe/4eb1fef8da7c6b1836d4a45038825168.jpg',
      'https://i.pinimg.com/1200x/a6/75/25/a6752574fe1bfe4737f164f93153ea94.jpg',
      'https://i.pinimg.com/736x/92/ec/41/92ec413a5eabfb122287f5ea56bda841.jpg'
    ],
    whatsappMessage: 'Hi Elite Kitchen, I\'m interested in PR11 - Innovative Glass Top Sleek Stove 2 Burner Jumbo + Large. Could you provide more details and pricing? 📦'
  }
];

// ============================================
// TESTIMONIALS DATA
// ============================================

const testimonialsData = [
  {
    id: 'test1',
    rating: 5,
    quote: 'Absolutely love the Cast Iron Premium Set! Quality is exceptional and the price is unbeatable. Best purchase I\'ve made for my kitchen!',
    author: 'Sarah Johnson',
    location: 'Bangalore, India',
    image: 'https://i.pravatar.cc/150?img=1'
  },
  {
    id: 'test2',
    rating: 5,
    quote: 'The triply cookware has completely changed how I cook. Everything heats evenly, and cleanup is a breeze. Highly recommend!',
    author: 'Rajesh Kumar',
    location: 'Mumbai, India',
    image: 'https://i.pravatar.cc/150?img=2'
  },
  {
    id: 'test3',
    rating: 5,
    quote: 'Premium quality at these prices? Unreal! The Winter Combi Hotbox Set is stunning and keeps food warm for hours. Will definitely buy more!',
    author: 'Priya Sharma',
    location: 'Delhi, India',
    image: 'https://i.pravatar.cc/150?img=3'
  },
  {
    id: 'test4',
    rating: 4.5,
    quote: 'Great products overall. The Travel Combi Set is perfect for our family trips. Delivery was quick too!',
    author: 'Amit Patel',
    location: 'Ahmedabad, India',
    image: 'https://i.pravatar.cc/150?img=4'
  },
  {
    id: 'test5',
    rating: 5,
    quote: 'Your customer service was amazing! They helped me choose the perfect combo for my needs. Very satisfied with everything!',
    author: 'Anjali Desai',
    location: 'Pune, India',
    image: 'https://i.pravatar.cc/150?img=5'
  },
  {
    id: 'test6',
    rating: 5,
    quote: 'Finally found a brand that offers both quality and value. The Aptiva SS Stove is perfect for my kitchen!',
    author: 'Vikram Singh',
    location: 'Chennai, India',
    image: 'https://i.pravatar.cc/150?img=6'
  }
];

// ============================================
// UTILITY FUNCTIONS
// ============================================

function smoothScroll(target) {
  const element = document.querySelector(target);
  if (element) {
    const offset = 80; // Adjusted for new navbar height
    const elementPosition = element.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - offset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  }
}

function generateWhatsAppLink(message) {
  const phoneNumber = '+919876543210';
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
}

// ============================================
// RENDER FUNCTIONS
// ============================================

function renderCombos() {
  const grid = document.getElementById('combosGrid');
  if (!grid) return;

  grid.innerHTML = combosData.map((combo, index) => `
    <div class="combo-card" data-observe style="transition-delay: ${index * 50}ms" onclick="openProductModal('${combo.id}')">
      <div class="combo-card__image-wrapper">
        <img src="${combo.image}" alt="${combo.title}" class="combo-card__image" loading="lazy">
      </div>
      <div class="combo-card__content">
        <h3 class="combo-card__title">${combo.title}</h3>
        <p class="combo-card__description">${combo.description}</p>
        <div class="combo-card__price">₹${combo.price}</div>
        <div class="combo-card__actions">
          <button class="combo-card__cta combo-card__cta--secondary" onclick="event.stopPropagation(); openProductModal('${combo.id}')">
            View Details
          </button>
          <a href="${generateWhatsAppLink(combo.whatsappMessage)}" 
             target="_blank" 
             rel="noopener noreferrer"
             class="combo-card__cta combo-card__cta--primary" 
             onclick="event.stopPropagation()">
            Buy Now
          </a>
        </div>
      </div>
    </div>
  `).join('');

  observeElements();
}

function renderTestimonials() {
  const grid = document.getElementById('testimonialsGrid');
  if (!grid) return;

  grid.innerHTML = testimonialsData.map((testimonial, index) => `
    <div class="testimonial-card" data-observe style="transition-delay: ${index * 100}ms">
      <p class="testimonial-card__quote">"${testimonial.quote}"</p>
      <div class="testimonial-card__author">
        <img src="${testimonial.image}" alt="${testimonial.author}" class="testimonial-card__avatar" loading="lazy">
        <div>
          <div class="testimonial-card__name">${testimonial.author}</div>
          <div class="testimonial-card__location">${testimonial.location}</div>
        </div>
      </div>
    </div>
  `).join('');

  observeElements();
}

// ============================================
// INTERSECTION OBSERVER
// ============================================

function observeElements() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  document.querySelectorAll('[data-observe]').forEach(el => {
    observer.observe(el);
  });
}

// ============================================
// NAVIGATION FUNCTIONALITY
// ============================================

function initNavigation() {
  const hamburger = document.getElementById('hamburger');
  const navbar = document.getElementById('navbar');
  const glassMenu = document.querySelector('.navbar__glass.mobile-menu');

  if (hamburger && glassMenu) {
    hamburger.addEventListener('click', (e) => {
      e.stopPropagation();
      glassMenu.classList.toggle('active');
      document.body.style.overflow = glassMenu.classList.contains('active') ? 'hidden' : '';
    });

    document.addEventListener('click', (e) => {
      if (!glassMenu.contains(e.target) && !hamburger.contains(e.target)) {
        glassMenu.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  // Navbar scroll effect
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.pageYOffset > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
      
      // Update Active State for Bottom Nav
      updateActiveNavLink();
    });
  }
}

function updateActiveNavLink() {
  const sections = document.querySelectorAll('section');
  const navLinks = document.querySelectorAll('.bottom-nav__item');
  
  let current = '';
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;
    if (pageYOffset >= (sectionTop - 300)) {
      current = section.getAttribute('id');
    }
  });

  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href').includes(current)) {
      link.classList.add('active');
    }
  });
}

// ============================================
// PRODUCT MODAL FUNCTIONALITY
// ============================================

function openProductModal(comboId) {
  const combo = combosData.find(c => c.id === comboId);
  if (!combo) return;

  const modal = document.getElementById('productModal');
  const modalBody = document.getElementById('productModalBody');
  
  const images = combo.images || [combo.image, combo.image, combo.image, combo.image, combo.image];
  
  modalBody.innerHTML = `
    <div class="product-details">
      <div class="product-details__image-section">
        <div class="product-image__main-wrapper" id="mainImageWrapper">
          <img src="${images[0]}" alt="${combo.title}" class="product-details__image" id="mainProductImage">
        </div>
        <div class="product-image__thumbnails">
          ${images.map((img, index) => `
            <div class="thumbnail-item ${index === 0 ? 'active' : ''}" onclick="changeMainImage(${index}, '${img}')">
              <img src="${img}" alt="View ${index + 1}" class="thumbnail-image">
            </div>
          `).join('')}
        </div>
      </div>
      <div class="product-details__info">
        <div class="product-details__brand">ELITE KITCHEN</div>
        <h1 class="product-details__title">${combo.title}</h1>
        <div class="product-details__code">${combo.id}</div>
        
        <div class="product-details__description">
          <h3 class="product-details__section-title">Description</h3>
          <p class="product-details__text">${combo.description}</p>
        </div>
        
        <div class="product-details__price-section">
          <div class="product-details__price-label">Price</div>
          <div class="product-details__price">₹${combo.price}</div>
        </div>
        
        <div class="product-details__actions">
          <a href="${generateWhatsAppLink(combo.whatsappMessage)}" 
             target="_blank" 
             rel="noopener noreferrer"
             class="product-details__cta product-details__cta--primary">
            Buy Now
          </a>
        </div>
      </div>
    </div>
  `;
  
  initImageZoom();
  modal.classList.add('active');
  document.body.classList.add('modal-open');
}

function changeMainImage(index, imageUrl) {
  const mainImage = document.getElementById('mainProductImage');
  const thumbnails = document.querySelectorAll('.thumbnail-item');
  
  if (mainImage) {
    mainImage.style.opacity = '0';
    setTimeout(() => {
      mainImage.src = imageUrl;
      mainImage.style.opacity = '1';
    }, 150);
  }
  
  thumbnails.forEach((thumb, i) => {
    thumb.classList.toggle('active', i === index);
  });
}

function initImageZoom() {
  const wrapper = document.getElementById('mainImageWrapper');
  const img = document.getElementById('mainProductImage');
  
  if (!wrapper || !img) return;
  
  wrapper.addEventListener('mousemove', (e) => {
    const { left, top, width, height } = wrapper.getBoundingClientRect();
    const x = (e.clientX - left) / width;
    const y = (e.clientY - top) / height;
    
    img.style.transformOrigin = `${x * 100}% ${y * 100}%`;
    img.style.transform = 'scale(2)';
  });
  
  wrapper.addEventListener('mouseleave', () => {
    img.style.transform = 'scale(1)';
    setTimeout(() => {
      img.style.transformOrigin = 'center center';
    }, 300);
  });
}

function closeProductModal() {
  const modal = document.getElementById('productModal');
  modal.classList.remove('active');
  document.body.classList.remove('modal-open');
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeProductModal();
});

document.addEventListener('DOMContentLoaded', () => {
  renderCombos();
  renderTestimonials();
  initNavigation();
  observeElements();
});
